"""
Временная конфигурация с рабочим токеном для деплоя
"""
import os
from app.config import Settings

# АВАРИЙНЫЙ РЕЖИМ - используем последний РАБОЧИЙ токен
NEW_BOT_TOKEN = "7393209394:AAFXGamauF3PaaTYcyHW6Bxn_sJPyfptAcU"

def get_working_settings():
    """Получить настройки с рабочим токеном"""
    # Загружаем настройки из переменных окружения
    cfg = Settings.from_env()
    
    # Заменяем проблемный токен на рабочий
    cfg.BOT_TOKEN = NEW_BOT_TOKEN
    
    # ВКЛЮЧАЕМ ПРОВЕРКУ ГРУППЫ - БОТ УЖЕ АДМИНИСТРАТОР
    cfg.SKIP_GROUP_CHECK = False
    
    print(f"🔧 Используем рабочий токен: {NEW_BOT_TOKEN[:20]}...")
    print(f"📋 Остальные настройки:")
    print(f"   - Admin IDs: {cfg.ADMIN_IDS}")
    print(f"   - Channel ID: {cfg.REQUIRED_CHANNEL_ID}")
    print(f"   - Group ID: {cfg.REQUIRED_GROUP_ID}")
    print(f"   - SKIP_GROUP_CHECK: {cfg.SKIP_GROUP_CHECK} (бот администратор - включено)")
    
    return cfg