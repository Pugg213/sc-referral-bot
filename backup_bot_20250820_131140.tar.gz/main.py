import asyncio
import logging
import os
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from app.config import Settings
from app.db import Database
from app.context import set_context
from app.handlers.start_fixed import router as start_router
from app.handlers.core import router as core_router
from app.services.validator import validator_loop

logging.basicConfig(level=logging.INFO)

async def main():
    """
    Main entry point - supports both polling and webhook modes
    Detects deployment environment automatically
    """
    
    # Check if this is a deployment environment
    is_deployment = os.getenv('REPL_DEPLOYMENT') == '1' or any([
        os.getenv('RAILWAY_ENVIRONMENT_NAME'),
        os.getenv('HEROKU_APP_NAME'), 
        os.getenv('RENDER_SERVICE_NAME'),
        os.getenv('REPLIT_DOMAINS')
    ])
    
    if is_deployment:
        # Use deployment manager for production
        try:
            from main_deploy import BotManager
            manager = BotManager()
            await manager.initialize()
            
            # Get deployment config and start in appropriate mode
            deploy_config = {'mode': 'webhook', 'port': 5000, 'webhook_url': None}
            
            if deploy_config['mode'] == 'webhook':
                await manager.start_webhook_mode(
                    port=deploy_config['port'],
                    webhook_url=deploy_config['webhook_url']
                )
            else:
                await manager.start_polling_mode()
            return
            
        except Exception as e:
            logging.error(f"Deployment mode failed: {e}")
            # Fall back to polling mode
    
    # Original polling mode for development
    try:
        from temp_config import get_working_settings
        cfg = get_working_settings()
        print("🔧 Используем временную конфигурацию с рабочим токеном")
    except ImportError:
        cfg = Settings.from_env()
        print("📋 Используем стандартную конфигурацию")
    
    # Debug: Check if essential config is loaded
    if not cfg.BOT_TOKEN:
        logging.error("BOT_TOKEN is not set or empty!")
        return
    
    if not cfg.REQUIRED_CHANNEL_ID:
        logging.error("REQUIRED_CHANNEL_ID is not set or empty!")
        return
        
    if not cfg.REQUIRED_GROUP_ID:
        logging.error("REQUIRED_GROUP_ID is not set or empty!")
        return
        
    if not cfg.ADMIN_IDS:
        logging.error("No admin IDs found! Check MAIN_ADMIN_ID environment variable.")
        return
    
    # Clean the bot token of any whitespace
    clean_token = cfg.BOT_TOKEN.strip()
    
    logging.info(f"Bot token length: {len(clean_token)} characters")
    
    # More detailed token format check
    if ':' not in clean_token:
        logging.error("BOT_TOKEN format appears invalid - should contain ':' character")
        logging.error("Expected format: 123456789:ABC-DEF1234ghIkl-zyx57W2v1u123ew11")
        return
    
    # Show token parts for debugging (safely)
    token_parts = clean_token.split(':')
    if len(token_parts) != 2:
        logging.error("BOT_TOKEN should have exactly one ':' character")
        return
    
    bot_id = token_parts[0]
    token_secret = token_parts[1]
    
    logging.info(f"Bot ID: {bot_id} (length: {len(bot_id)})")
    logging.info(f"Token secret length: {len(token_secret)} characters")
    logging.info(f"Token starts with: {clean_token[:10]}...")
    logging.info(f"Token ends with: ...{clean_token[-10:]}")
    
    logging.info(f"Admin IDs: {cfg.ADMIN_IDS}")
    logging.info(f"Required Channel ID: {cfg.REQUIRED_CHANNEL_ID}")
    logging.info(f"Required Group ID: {cfg.REQUIRED_GROUP_ID}")
    
    bot = Bot(token=clean_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    
    # Test bot token validity before proceeding
    try:
        bot_info = await bot.get_me()
        logging.info(f"Bot authenticated successfully: @{bot_info.username} ({bot_info.first_name})")
    except Exception as e:
        logging.error(f"Bot token authentication failed: {e}")
        logging.error("Please check that:")
        logging.error("1. BOT_TOKEN is correct and copied exactly from @BotFather")
        logging.error("2. The bot hasn't been deleted or revoked")
        logging.error("3. There are no extra spaces or characters in the token")
        return
    
    dp = Dispatcher()

    db = Database(cfg.DB_PATH)
    try:
        db.init()
        logging.info("Database initialized successfully")
    except Exception as e:
        logging.error(f"Database initialization failed: {e}")
        return

    set_context(cfg=cfg, db=db)

    # Новая архитектура роутеров (чистая и функциональная)
    from app.handlers import navigation_production, start_fixed, admin_clean, core, wallet, checkin
    from aiogram import Router, F
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    
    # Создаем emergency router для критических handlers
    emergency_router = Router()
    
    # Регистрируем роутеры в правильном порядке
    dp.include_router(navigation_production.router)
    logging.info("✅ Navigation router registered")
    
    dp.include_router(start_fixed.router) 
    logging.info("✅ Start fixed router registered")
    
    # Добавляем минимальный task handler ПЕРЕД admin_clean
    try:
        # Task router integrated into admin_clean.py
        logging.info("✅ Task functionality integrated into admin_clean")
    except Exception as e:
        logging.error(f"❌ Task minimal failed: {e}")
        # Добавляем inline handler для tasks_manager
        @emergency_router.callback_query(F.data == "tasks_manager")
        async def emergency_tasks_manager(callback):
            text = "🎯 Менеджер заданий\n\nИспользуйте /add_task для создания заданий"
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🔙 Назад", callback_data="admin_back")]
            ])
            await callback.message.edit_text(text, reply_markup=keyboard)
            await callback.answer()
        dp.include_router(emergency_router)
        logging.info("✅ Emergency task handler added")
    
    dp.include_router(admin_clean.router)
    logging.info("✅ Admin clean router registered")
    
    dp.include_router(checkin.router)
    logging.info("✅ Checkin system router registered")
    
    dp.include_router(core.router)
    logging.info("✅ Core router registered")
    
    dp.include_router(wallet.router)
    logging.info("✅ Wallet router registered")

    # Background validator loop with better error handling
    validator_task = asyncio.create_task(validator_loop(bot))
    logging.info("Validator loop started")

    logging.info("Bot is starting...")
    
    # Handle bot conflicts by clearing existing webhooks and dropping pending updates
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        logging.info("Cleared any existing webhooks to prevent conflicts")
        await asyncio.sleep(1)  # Brief pause to ensure cleanup
    except Exception as e:
        logging.warning(f"Webhook cleanup warning: {e}")
    
    try:
        await dp.start_polling(
            bot,
            drop_pending_updates=True,  # Drop pending updates to avoid conflicts
            handle_signals=False  # Let the main process handle signals properly
        )
    except Exception as e:
        logging.error(f"Polling failed: {e}")
        # Try to cleanup before failing
        try:
            await bot.session.close()
        except:
            pass
        raise

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        print("Bot stopped.")
