#!/usr/bin/env python3
"""
КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: НАЧИСЛЕНИЕ НАГРАД ЗА РЕФЕРАЛОВ
Проблема: Рефереры не получали 1.0 SC за каждого валидированного реферала
"""
import sqlite3

def fix_referral_rewards():
    print("🚨 КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ НАГРАД ЗА РЕФЕРАЛОВ")
    print("=" * 60)
    
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    
    # 1. Найти всех рефереров с валидированными рефералами
    print("🔍 Ищу рефереров которые должны получить награды...")
    cursor.execute("""
        SELECT u.user_id, u.username, u.validated_referrals, 
               u.total_earnings, u.balance, u.pending_balance
        FROM users u
        WHERE u.validated_referrals > 0
        ORDER BY u.validated_referrals DESC
    """)
    
    referrers = cursor.fetchall()
    print(f"📊 Найдено {len(referrers)} рефереров с валидированными рефералами")
    
    if len(referrers) == 0:
        print("✅ Нет рефереров для начисления наград!")
        conn.close()
        return
    
    print("\n💰 НАЧИСЛЯЮ НАГРАДЫ ЗА РЕФЕРАЛОВ (1.0 SC за каждого):")
    
    total_rewards_added = 0
    
    for user_id, username, validated_referrals, total_earnings, balance, pending_balance in referrers:
        referral_rewards = validated_referrals * 1.0  # 1.0 SC за каждого реферала
        
        print(f"\n👤 Рефререр {user_id} (@{username}):")
        print(f"   Валидированных рефералов: {validated_referrals}")
        print(f"   Должен получить: {referral_rewards} SC")
        print(f"   Текущие earnings: {total_earnings} SC")
        print(f"   Текущий balance: {balance} SC")
        
        # Проверим, получал ли уже награды за рефералов
        cursor.execute("""
            SELECT COUNT(*) as capsule_count, COALESCE(SUM(reward_amount), 0) as capsule_earnings
            FROM capsule_openings 
            WHERE user_id = ?
        """, (user_id,))
        
        capsule_data = cursor.fetchone()
        capsule_count, capsule_earnings = capsule_data if capsule_data else (0, 0)
        
        expected_total = capsule_earnings + referral_rewards
        
        print(f"   Награды с капсул: {capsule_earnings} SC ({capsule_count} капсул)")
        print(f"   Ожидаемый total: {expected_total} SC")
        
        # Если current total_earnings меньше ожидаемого, начисляем разницу
        if total_earnings < expected_total:
            missing_rewards = expected_total - total_earnings
            
            print(f"   🔧 НАЧИСЛЯЮ НЕДОСТАЮЩЕЕ: {missing_rewards} SC")
            
            # Начисляем недостающие награды
            cursor.execute("""
                UPDATE users 
                SET balance = balance + ?, 
                    pending_balance = pending_balance + ?,
                    total_earnings = total_earnings + ?
                WHERE user_id = ?
            """, (missing_rewards, missing_rewards, missing_rewards, user_id))
            
            total_rewards_added += missing_rewards
            print(f"   ✅ ИСПРАВЛЕНО: добавлено {missing_rewards} SC")
            
        elif total_earnings > expected_total:
            extra = total_earnings - expected_total
            print(f"   ℹ️ У пользователя {extra} SC сверх ожидаемого (возможно чек-ины)")
        else:
            print(f"   ✅ Баланс уже правильный")
    
    # 2. Проверяем правильность начислений
    print(f"\n🧮 ИТОГОВАЯ ПРОВЕРКА:")
    cursor.execute("""
        SELECT COUNT(*) as total_users, 
               SUM(validated_referrals) as total_refs,
               SUM(total_earnings) as total_earnings_all
        FROM users 
        WHERE validated_referrals > 0
    """)
    
    summary = cursor.fetchone()
    if summary:
        total_users, total_refs, total_earnings_all = summary
        print(f"👥 Всего рефереров: {total_users}")
        print(f"🎯 Всего валидированных рефералов: {total_refs}")
        print(f"💰 Общие earnings у рефереров: {total_earnings_all} SC")
        print(f"🎁 Должно быть наград за рефералов: {total_refs * 1.0} SC")
    
    conn.commit()
    conn.close()
    
    print(f"\n🏆 ИСПРАВЛЕНИЕ ЗАВЕРШЕНО!")
    print(f"💰 Добавлено наград: {total_rewards_added} SC")
    print("✅ Все рефереры теперь получили правильные награды")
    print("✅ Новые рефералы будут автоматически награждаться 1.0 SC")

if __name__ == "__main__":
    fix_referral_rewards()