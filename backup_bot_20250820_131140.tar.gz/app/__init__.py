"""
SC Referral Bot - Telegram bot with capsule referral system
"""
