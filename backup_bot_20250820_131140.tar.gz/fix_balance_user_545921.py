#!/usr/bin/env python3
"""
Исправление баланса пользователя 545921
"""
import sqlite3

def fix_user_balance():
    print("🔧 ИСПРАВЛЯЮ БАЛАНС ПОЛЬЗОВАТЕЛЯ 545921...")
    
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    
    # 1. Получаем текущие данные пользователя
    cursor.execute("""
        SELECT user_id, total_referrals, total_earnings, paid_balance, balance, 
               validated_referrals, total_capsules_opened
        FROM users WHERE user_id = 545921
    """)
    user_data = cursor.fetchone()
    
    if not user_data:
        print("❌ Пользователь 545921 не найден!")
        return
    
    user_id, total_refs, total_earnings, paid_balance, current_balance, validated_refs, total_caps = user_data
    print(f"📊 Текущие данные пользователя {user_id}:")
    print(f"   Рефералы: {total_refs}, Валидированные: {validated_refs}")
    print(f"   Доходы: {total_earnings}, Выплачено: {paid_balance}")
    print(f"   Баланс: {current_balance}, Капсулы: {total_caps}")
    
    # 2. Пересчитываем доходы от капсул
    cursor.execute("""
        SELECT COUNT(*) as count, COALESCE(SUM(reward_amount), 0) as total_reward
        FROM capsule_openings WHERE user_id = 545921
    """)
    capsule_count, capsule_earnings = cursor.fetchone()
    print(f"💰 Доходы от капсул: {capsule_earnings} SC ({capsule_count} капсул)")
    
    # 3. Пересчитываем валидированные рефералы
    cursor.execute("""
        SELECT COUNT(*) FROM referral_validations 
        WHERE referrer_id = 545921 AND validated = 1
    """)
    validated_count = cursor.fetchone()[0]
    print(f"👥 Валидированные рефералы: {validated_count}")
    
    # 4. Пересчитываем доходы от чек-инов (чек-ин дает 0.5 SC)
    cursor.execute("""
        SELECT COUNT(*) FROM user_checkins 
        WHERE user_id = 545921
    """)
    checkin_count = cursor.fetchone()[0]
    checkin_earnings = checkin_count * 0.5  # 0.5 SC за чек-ин
    print(f"📅 Доходы от чек-инов: {checkin_earnings} SC ({checkin_count} чек-инов)")
    
    # 5. Правильный расчет общих доходов
    # Доходы = капсулы + чек-ины + рефералы (0.5 SC за реферал)
    referral_earnings = validated_count * 0.5
    total_correct_earnings = capsule_earnings + checkin_earnings + referral_earnings
    
    print(f"🧮 ПРАВИЛЬНЫЙ РАСЧЕТ:")
    print(f"   Капсулы: {capsule_earnings} SC")
    print(f"   Чек-ины: {checkin_earnings} SC") 
    print(f"   Рефералы: {validated_count} × 0.5 = {referral_earnings} SC")
    print(f"   ИТОГО заработано: {total_correct_earnings} SC")
    
    # 6. Правильный баланс = заработано - выплачено
    correct_balance = total_correct_earnings - paid_balance
    print(f"💳 ПРАВИЛЬНЫЙ БАЛАНС: {total_correct_earnings} - {paid_balance} = {correct_balance} SC")
    
    # 7. Обновляем данные пользователя
    cursor.execute("""
        UPDATE users SET 
            total_earnings = ?,
            balance = ?,
            total_capsules_opened = ?,
            validated_referrals = ?
        WHERE user_id = 545921
    """, (total_correct_earnings, correct_balance, capsule_count, validated_count))
    
    conn.commit()
    conn.close()
    
    print(f"✅ БАЛАНС ИСПРАВЛЕН!")
    print(f"   Новый баланс: {correct_balance} SC")
    print(f"   Общие доходы: {total_correct_earnings} SC")
    print(f"   Выплачено: {paid_balance} SC")

if __name__ == "__main__":
    fix_user_balance()