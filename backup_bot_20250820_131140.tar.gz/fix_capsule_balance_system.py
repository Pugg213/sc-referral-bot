#!/usr/bin/env python3
"""
КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ СИСТЕМЫ БАЛАНСОВ КАПСУЛ
Проблема: add_balance() обновлял только pending_balance, но профили показывали balance
"""
import sqlite3

def fix_capsule_balance_system():
    print("🚨 КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ СИСТЕМЫ БАЛАНСОВ КАПСУЛ")
    print("=" * 60)
    
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    
    # 1. Найти всех пользователей с несинхронизированными балансами
    print("🔍 Ищу пользователей с несинхронизированными балансами...")
    cursor.execute("""
        SELECT user_id, username, pending_balance, balance, total_earnings, 
               (pending_balance - balance) as diff
        FROM users 
        WHERE ABS(pending_balance - balance) > 0.01 AND total_earnings > 0
        ORDER BY total_earnings DESC
    """)
    
    users_to_fix = cursor.fetchall()
    print(f"📊 Найдено {len(users_to_fix)} пользователей с проблемами баланса")
    
    if len(users_to_fix) == 0:
        print("✅ Все балансы синхронизированы!")
        conn.close()
        return
    
    print("\n🔧 ИСПРАВЛЯЮ БАЛАНСЫ:")
    for user_id, username, pending_balance, balance, total_earnings, diff in users_to_fix:
        print(f"\n👤 Пользователь {user_id} (@{username}):")
        print(f"   pending_balance: {pending_balance} SC")
        print(f"   balance: {balance} SC") 
        print(f"   total_earnings: {total_earnings} SC")
        print(f"   разница: {diff} SC")
        
        # Синхронизируем balance с pending_balance
        cursor.execute("""
            UPDATE users SET balance = pending_balance WHERE user_id = ?
        """, (user_id,))
        
        print(f"   ✅ ИСПРАВЛЕНО: balance = {pending_balance} SC")
    
    # 2. Проверяем правильность расчетов total_earnings
    print(f"\n🧮 ПРОВЕРЯЮ ПРАВИЛЬНОСТЬ РАСЧЕТОВ...")
    cursor.execute("""
        SELECT u.user_id, u.username, u.total_earnings,
               COALESCE(SUM(co.reward_amount), 0) as capsule_earnings,
               COUNT(co.id) as capsule_count
        FROM users u
        LEFT JOIN capsule_openings co ON u.user_id = co.user_id
        WHERE u.total_earnings > 0
        GROUP BY u.user_id
        HAVING ABS(u.total_earnings - COALESCE(SUM(co.reward_amount), 0)) > 0.01
    """)
    
    earnings_problems = cursor.fetchall()
    if earnings_problems:
        print(f"⚠️ Найдено {len(earnings_problems)} пользователей с неправильными total_earnings:")
        for user_id, username, total_earnings, capsule_earnings, capsule_count in earnings_problems:
            print(f"   👤 {user_id} (@{username}): {total_earnings} SC (должно быть {capsule_earnings} SC)")
    else:
        print("✅ Все total_earnings корректны")
    
    # 3. Проверяем корректность записей в capsule_openings
    print(f"\n📦 ПРОВЕРЯЮ ЗАПИСИ КАПСУЛ...")
    cursor.execute("""
        SELECT user_id, COUNT(*) as count, SUM(reward_amount) as total_reward,
               MIN(reward_amount) as min_reward, MAX(reward_amount) as max_reward
        FROM capsule_openings
        GROUP BY user_id
        ORDER BY total_reward DESC
        LIMIT 10
    """)
    
    capsule_stats = cursor.fetchall()
    print("📊 ТОП-10 по капсулам:")
    for user_id, count, total_reward, min_reward, max_reward in capsule_stats:
        cursor.execute("SELECT username FROM users WHERE user_id = ?", (user_id,))
        username = cursor.fetchone()
        username = username[0] if username else "Unknown"
        print(f"   {user_id} (@{username}): {count} капсул, {total_reward} SC ({min_reward}-{max_reward} SC)")
    
    conn.commit()
    conn.close()
    
    print(f"\n🏆 ИСПРАВЛЕНИЕ ЗАВЕРШЕНО!")
    print("✅ Все балансы синхронизированы")
    print("✅ add_balance() теперь обновляет оба поля")
    print("✅ Пользователи увидят правильные балансы")

if __name__ == "__main__":
    fix_capsule_balance_system()