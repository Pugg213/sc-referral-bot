#!/usr/bin/env python3
"""
Исправление проблем с каналами
"""
import asyncio
import os
from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

async def test_different_formats():
    """Тестируем разные форматы ID"""
    bot_token = os.getenv("BOT_TOKEN")
    channel_id = os.getenv("REQUIRED_CHANNEL_ID")
    group_id = os.getenv("REQUIRED_GROUP_ID")
    
    bot = Bot(token=bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    
    # Получаем обновления чтобы найти чаты где бот администратор
    print("🔍 Проверяем чаты где бот является администратором...")
    
    try:
        # Попробуем получить информацию о боте
        me = await bot.get_me()
        print(f"Бот: @{me.username} (ID: {me.id})")
        
        # Если каналы существуют, попробуем разные форматы
        test_ids = []
        
        if channel_id:
            test_ids.extend([
                channel_id,
                channel_id.replace("-100", ""),
                f"-100{channel_id}" if not channel_id.startswith("-100") else channel_id
            ])
        
        if group_id and group_id != channel_id:
            test_ids.extend([
                group_id,
                group_id.replace("-100", ""),
                f"-100{group_id}" if not group_id.startswith("-100") else group_id
            ])
        
        for test_id in test_ids:
            try:
                chat = await bot.get_chat(test_id)
                print(f"✅ Найден чат: {chat.title} (ID: {chat.id}, тип: {chat.type})")
                
                # Проверим статус бота
                bot_member = await bot.get_chat_member(test_id, me.id)
                print(f"   Статус бота: {bot_member.status}")
                
                if bot_member.status in ['administrator', 'creator']:
                    print(f"   🎉 Правильный ID для использования: {chat.id}")
                
            except Exception as e:
                continue
        
    except Exception as e:
        print(f"Ошибка: {e}")
    
    await bot.session.close()

if __name__ == "__main__":
    asyncio.run(test_different_formats())