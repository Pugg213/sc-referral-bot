#!/usr/bin/env python3
"""
ЭКСТРЕННОЕ ИСПРАВЛЕНИЕ ЗАВИСШЕГО БОТА + ВОССТАНОВЛЕНИЕ РЕФЕРАЛОВ
"""

import asyncio
import aiohttp
import json
import logging
import sqlite3
import os

async def emergency_webhook_fix():
    token = "7393209394:AAFXGamaurT9FMzJJV1fqPNNFnHQMIUQHPU"
    webhook_url = "https://a6f5cf38-d982-4526-a2b2-00e47ba5cb81-00-128py9dcpc4h7.picard.replit.dev/webhook"
    
    print("🚨 ЭКСТРЕННОЕ ИСПРАВЛЕНИЕ WEBHOOK...")
    
    async with aiohttp.ClientSession() as session:
        # 1. Удаляем текущий webhook
        print("🗑️ Удаляю старый webhook...")
        delete_url = f"https://api.telegram.org/bot{token}/deleteWebhook?drop_pending_updates=true"
        async with session.post(delete_url) as resp:
            result = await resp.json()
            print(f"✅ Webhook удален: {result.get('ok', False)}")
        
        # 2. Ждем 2 секунды
        await asyncio.sleep(2)
        
        # 3. Устанавливаем новый webhook
        print("🔗 Устанавливаю новый webhook...")
        set_url = f"https://api.telegram.org/bot{token}/setWebhook"
        data = {
            "url": webhook_url,
            "max_connections": 40,
            "drop_pending_updates": True
        }
        async with session.post(set_url, json=data) as resp:
            result = await resp.json()
            print(f"✅ Webhook установлен: {result.get('ok', False)}")
            if result.get('description'):
                print(f"📝 Описание: {result['description']}")
        
        # 4. Проверяем статус
        print("🔍 Проверяю статус webhook...")
        info_url = f"https://api.telegram.org/bot{token}/getWebhookInfo"
        async with session.get(info_url) as resp:
            result = await resp.json()
            if result.get('ok'):
                webhook_info = result['result']
                print(f"✅ URL: {webhook_info.get('url', 'Не установлен')}")
                print(f"✅ Pending updates: {webhook_info.get('pending_update_count', 0)}")
                print(f"✅ Последняя ошибка: {webhook_info.get('last_error_message', 'Нет ошибок')}")

def emergency_data_restore():
    """Экстренное восстановление данных пользователей"""
    print("\n🔧 ЗАПУСКАЮ ЭКСТРЕННОЕ ВОССТАНОВЛЕНИЕ ДАННЫХ...")
    
    if not os.path.exists('bot.db'):
        print("❌ База данных не найдена!")
        return False
    
    try:
        conn = sqlite3.connect('bot.db', timeout=10.0)  # Таймаут для избежания блокировок
        cursor = conn.cursor()
        
        # 1. Пересчет рефералов
        print("📊 Восстанавливаю рефералы...")
        cursor.execute("""
            UPDATE users SET 
                total_referrals = (
                    SELECT COUNT(*) 
                    FROM users u2 
                    WHERE u2.referrer_id = users.user_id
                ),
                validated_referrals = (
                    SELECT COUNT(*) 
                    FROM referral_validations rv 
                    WHERE rv.referrer_id = users.user_id 
                    AND rv.validated = 1
                )
            WHERE user_id IN (
                SELECT DISTINCT referrer_id 
                FROM users 
                WHERE referrer_id IS NOT NULL
            )
        """)
        referrals_updated = cursor.rowcount
        
        # 2. Пересчет доходов
        print("💰 Восстанавливаю доходы...")
        cursor.execute("""
            UPDATE users SET 
                total_earnings = (
                    SELECT COALESCE(SUM(sc_amount), 0) 
                    FROM capsule_openings co 
                    WHERE co.user_id = users.user_id
                ) + (
                    SELECT COALESCE(SUM(sc_amount), 0) 
                    FROM user_checkins uc 
                    WHERE uc.user_id = users.user_id
                )
        """)
        
        # 3. Пересчет балансов
        cursor.execute("""
            UPDATE users SET 
                pending_balance = total_earnings - paid_balance
        """)
        
        conn.commit()
        
        # Финальная проверка
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM users WHERE total_referrals > 0")
        users_with_refs = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(total_referrals) FROM users")
        total_refs = cursor.fetchone()[0] or 0
        
        print(f"✅ Восстановлено {referrals_updated} пользователей с рефералами")
        print(f"✅ Всего пользователей: {total_users}")
        print(f"✅ Пользователей с рефералами: {users_with_refs}")
        print(f"✅ Всего рефералов в системе: {total_refs}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Ошибка восстановления данных: {e}")
        return False

async def main():
    """Главная функция - webhook + данные"""
    print("🚨 ЭКСТРЕННОЕ ВОССТАНОВЛЕНИЕ СИСТЕМЫ")
    print("=" * 50)
    
    # 1. Восстановление webhook
    await emergency_webhook_fix()
    
    # 2. Восстановление данных
    emergency_data_restore()
    
    print("\n✅ ЭКСТРЕННОЕ ВОССТАНОВЛЕНИЕ ЗАВЕРШЕНО!")

if __name__ == "__main__":
    asyncio.run(main())