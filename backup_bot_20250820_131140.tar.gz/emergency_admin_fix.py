#!/usr/bin/env python3
"""
🚨 ЭКСТРЕННОЕ ИСПРАВЛЕНИЕ - БОТ НЕ ОТВЕЧАЕТ АДМИНУ
"""

import sqlite3
import sys
from datetime import datetime

def diagnose_admin_issue():
    """Диагностика проблемы с доступом админа"""
    
    print("🔍 ДИАГНОСТИКА ПРОБЛЕМЫ С АДМИНОМ")
    print("="*50)
    
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    
    # Проверяем админа
    cursor.execute("SELECT user_id, username, subscription_checked, banned FROM users WHERE user_id = 545921")
    admin = cursor.fetchone()
    
    if admin:
        user_id, username, sub_checked, banned = admin
        print(f"👤 АДМИН 545921 НАЙДЕН:")
        print(f"   Username: {username}")
        print(f"   Подписан: {'✅ Да' if sub_checked else '❌ НЕТ'}")
        print(f"   Забанен: {'❌ Да' if banned else '✅ Нет'}")
        
        if not sub_checked:
            print(f"\n🚨 ПРОБЛЕМА: АДМИН НЕ ПОДПИСАН!")
            print(f"   Middleware блокирует админа!")
            return "admin_not_subscribed"
        
        if banned:
            print(f"\n🚨 ПРОБЛЕМА: АДМИН ЗАБАНЕН!")
            return "admin_banned"
            
    else:
        print(f"❌ АДМИН 545921 НЕ НАЙДЕН В БАЗЕ!")
        return "admin_not_registered"
    
    # Проверяем обработчики команд
    print(f"\n🔍 ПРОВЕРКА ОБРАБОТЧИКОВ:")
    print(f"   /admin - должен быть доступен админу")
    print(f"   /stats - должен быть доступен админу") 
    print(f"   Middleware может блокировать все команды")
    
    conn.close()
    return "admin_found_checking_handlers"

def fix_admin_subscription():
    """Принудительно восстановить подписку админа"""
    
    conn = sqlite3.connect('bot.db')
    cursor = conn.cursor()
    
    # Обновляем статус подписки админа
    cursor.execute("""
        UPDATE users 
        SET subscription_checked = 1, 
            banned = 0
        WHERE user_id = 545921
    """)
    
    if cursor.rowcount > 0:
        conn.commit()
        print("✅ Статус подписки админа восстановлен!")
    else:
        print("❌ Админ не найден для обновления")
    
    conn.close()

if __name__ == "__main__":
    print("🚨 ЭКСТРЕННОЕ ИСПРАВЛЕНИЕ ДОСТУПА АДМИНА")
    print("="*60)
    
    # Диагностика
    issue = diagnose_admin_issue()
    
    if issue == "admin_not_subscribed":
        print("\n🔧 ИСПРАВЛЯЮ: Восстанавливаю подписку админа...")
        fix_admin_subscription()
        print("✅ ИСПРАВЛЕНИЕ ЗАВЕРШЕНО!")
        print("🔄 Админ теперь может использовать команды!")
    
    elif issue == "admin_banned":
        print("\n🔧 ИСПРАВЛЯЮ: Снимаю бан с админа...")
        fix_admin_subscription()
        print("✅ ИСПРАВЛЕНИЕ ЗАВЕРШЕНО!")
    
    elif issue == "admin_not_registered":
        print("\n⚠️ ТРЕБУЕТСЯ: Админ должен выполнить /start в боте")
        print("   Тогда он будет зарегистрирован в системе")
    
    else:
        print(f"\n🤔 ПРОБЛЕМА НЕ В БАЗЕ ДАННЫХ")
        print(f"   Возможные причины:")
        print(f"   1. Middleware блокирует команды")
        print(f"   2. Проблема с роутерами")
        print(f"   3. Webhook не доставляет сообщения")
        
    print(f"\n📝 СЛЕДУЮЩИЕ ШАГИ:")
    print(f"   1. Проверить что админ выполнил /start")
    print(f"   2. Проверить middleware настройки")
    print(f"   3. Отправить /admin в бота")