#!/usr/bin/env python3
"""
Deployment entry point for the Telegram bot
Automatically detects deployment environment and starts in appropriate mode
"""
import asyncio
import logging
import sys
import os

# Убедимся что мы в правильной директории
if not os.path.exists('app'):
    # Попробуем перейти в рабочую директорию
    workspace_paths = ['/home/runner/workspace', '.']
    for path in workspace_paths:
        if os.path.exists(f'{path}/app'):
            os.chdir(path)
            break

# Добавим текущую директорию в Python path
sys.path.insert(0, os.getcwd())

from main_deploy import main

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("Bot shutdown requested")
        sys.exit(0)
    except Exception as e:
        logging.error(f"Bot startup failed: {e}")
        sys.exit(1)